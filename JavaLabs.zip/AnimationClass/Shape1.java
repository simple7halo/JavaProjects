import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.Random;

public class Shape1 {
    private double x, y, r;
    private Color col;
    // add constructor, and required methods.
    public Shape1 (double x, double y, double r){
      this.x = x;
      this.y = y;
      this.r = r;
      Random rand = new Random();
      col = new Color(rand.nextInt(256),rand.nextInt(256),rand.nextInt(256));
    }

    public void setX(double x){
      this.x = x;
    }

    public void setY(double y){
      this.y = y;
    }

    public double getR(){
      return r;
    }

    public double getX(){
      return x;
    }

    public double getY(){
      return y;
    }

    public Color getColor(){
      return col;
    }

    public void draw(Graphics2D g2){
      // create a horizontal ellipse and then draw it
      double xTop = x - 2*r;
      double yTop = y - r;
      double width = 4*r;
      double height = 2*r;
      g2.setColor(getColor());
      Ellipse2D.Double s = new Ellipse2D.Double(xTop,yTop,width,height);
      g2.fill(s);
    }
    
 }