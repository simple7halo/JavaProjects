import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

public class Shape2 extends Shape1{
    
    public Shape2 (double x, double y, double r){
      super(x,y,r);
    }

    @Override
    public void draw(Graphics2D g2){
      // create and draw a vertical ellipse, and then invoke the superclass
      // draw(...) method to draw the horizontal ellipse.
      double xTop = getX() - getR();
      double yTop = getY() - 2*getR();
      double width = 2*getR();
      double height = 4*getR();
      g2.setColor(getColor());
      Ellipse2D.Double s = new Ellipse2D.Double(xTop,yTop,width,height);
      g2.fill(s);

      super.draw(g2);
        
    }
}