import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

public class Shape3 extends Shape2{
    
    public Shape3 (double x, double y, double r){
      super(x,y,r);
    }

    @Override    
    public void draw(Graphics2D g2){
        // create and draw a square then invoke the super class draw(...)
        // method to draw the vertical and horizontal ellipse.
        double xTop = getX() - 1.5*getR();
        double yTop = getY() - 1.5*getR();
        double width = 3*getR();
        double height = 3*getR();
        g2.setColor(getColor());
        Rectangle2D.Double box = new Rectangle2D.Double(xTop,yTop,width,height);
        g2.fill(box);

        super.draw(g2);
    
    }

}