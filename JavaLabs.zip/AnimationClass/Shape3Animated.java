import java.awt.Graphics2D;
import java.util.Random;
public class Shape3Animated extends Shape3{
   
    private int direction; // a random direction. //a random quadrant in 360 degree one
    private int degreeDirection; //direction represented by degree from 0-90
    private int velocity;  // a random velocity in pixel 
    // Add instance fields that required
    
    public Shape3Animated(double x, double y, double r){
        super(x,y,r);
        Random rand = new Random();
        direction = rand.nextInt(4);
        degreeDirection = rand.nextInt(90);
        velocity = rand.nextInt(8)+2;
    }
    // moves the x or y coordinates of the shape based on direction 
    // and velocity
    public void move(){  
        double newX,newY;
        switch(direction){
            case 0:
            newX = getX()+Math.abs((double)velocity*Math.cos(degreeDirection));
            newY = getY()-Math.abs((double)velocity*Math.sin(degreeDirection));
            if (newX >= 980 - 2*getR()) {
                direction = 1;
                break;
            }
            if (newY <= 2*getR()) {
                direction = 3;
                break;
            }
            setX(newX);
            setY(newY);
            break;
            case 1:
            newX = getX()-Math.abs((double)velocity*Math.cos(degreeDirection));
            newY = getY()-Math.abs((double)velocity*Math.sin(degreeDirection));
            if (newX <= 2*getR()) {
                direction = 0;
                break;
            }
            if (newY <= 2*getR()) {
                direction = 2;
                break;
            }
            setX(newX);
            setY(newY);
            break;
            case 2:
            newX = getX()-Math.abs((double)velocity*Math.cos(degreeDirection));
            newY = getY()+Math.abs((double)velocity*Math.sin(degreeDirection));
            if (newX <= 2*getR()) {
                direction = 3;
                break;
            }
            if (newY >= 680 + 2*getR()) {
                direction = 1;
                break;
            }
            setX(newX);
            setY(newY);
            break;
            case 3:
            newX = getX()+Math.abs((double)velocity*Math.cos(degreeDirection));
            newY = getY()+Math.abs((double)velocity*Math.sin(degreeDirection));
            if (newX >= 980 - 2*getR()) {
                direction = 2;
                break;
            }
            if (newY >= 680 - 2*getR()) {
                direction = 0;
                break;
            }
            setX(newX);
            setY(newY);
            break;
        }
        

        /* back up
        switch (direction){
            case 0: 
            setY(getY()-velocity);
            if (getY() - 2*getR() <= 0) direction = 2;
            break;
            case 1:
            setX(getX()+velocity);
            if (getX() + 2*getR() >= 1000) direction = 3;
            break;
            case 2:
            setY(getY()+velocity);
            if (getY() + 2*getR() >= 700) direction = 0;
            break;
            case 3:
            setX(getX()-velocity);
            if (getX() - 2*getR() <= 0) direction = 1;
            break;
        }
        */

    }

   @Override    
    public void draw(Graphics2D g2){
        super.draw(g2);
    }
}