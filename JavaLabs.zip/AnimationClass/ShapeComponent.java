import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.JComponent;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
*/
public class ShapeComponent extends JComponent
{  
	ArrayList<Shape3Animated> shapes = new ArrayList<Shape3Animated>();
	private Timer t;
	private final int shapeSize = 15;

	public ShapeComponent(){
		Random rand = new Random();
		for (int i=0; i < shapeSize; i++){
			double r = rand.nextDouble()*19+11;

			double x = rand.nextDouble()*(1000-4*r)+2*r;
			double y = rand.nextDouble()*(700-4*r)+2*r;
			
			shapes.add(new Shape3Animated(x,y,r));
		}
		StartTimer();
	}

	private void StartTimer(){
		class TimerListener implements ActionListener
		{
			public void actionPerformed(ActionEvent event)
			{
				for (Shape3Animated s: shapes){
					s.move();
				}
							
				repaint();
			}
		}
		t = new Timer(8, new TimerListener());
		t.start();
	}

	public void paintComponent(Graphics g)
	{  
		// Recover Graphics2D
		Graphics2D g2 = (Graphics2D) g;
	
		// Create your test cases here

		for(Shape3Animated s:shapes)
			s.draw(g2);

		
	  
	}
}
