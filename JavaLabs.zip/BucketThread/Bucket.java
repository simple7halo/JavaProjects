import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;
import java.util.Collections;
/**
* class Bucket manages an ArrayList of integer numbers
*/
public class Bucket{
	private ArrayList<Integer> bucket;
	private Lock lock;
	/** Default constructor*/
	public Bucket(){
		bucket = new ArrayList<Integer>();
		lock = new ReentrantLock();
	}
	/** add an element to the bucket
	* @param n: an integer number
	*/
	public void add(int n){
		lock.lock();
		try{
			bucket.add(n);
		}
	 	finally{
			 lock.unlock();
		 }
	}
	/** Returns the median value of the bucket, and then removes all of the elements from the bucket
	* @return the median of the bucket or returns -1 if bucket is empty
	* post condition: the elements of the bucket are removed
	*/
	public double median(){
		lock.lock();
		try{
			if(bucket.size()==0)
			return -1;
			Collections.sort(bucket);
			int median = bucket.get(bucket.size()/2);
			reset();
			return median;
		}finally{
			lock.unlock();
		}
	}
	/** Removes all of elements from the bucket
	*/
	private void reset(){
		bucket.clear();
	}
}