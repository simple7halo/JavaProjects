/**
 * CPSC 1181 lab assignment 10
 * practice multi-thread programing
 * @author :Qian Ting Huang
 * student #: 100307328
 * @version :2019-07-23
 */

/**
 * Bucket thread tester, interface of thread containing class
 * bucket, consumer and producer
 * will create instance of a bucket
 * instance of producer and consumer
 * start both thread
 */
import java.lang.Runnable;

public class BucketThreadTester
{
    static final int COUNT_DOWN = 30;
    /**
     * main method
     */
    public static void main(String[] args)
    {
        Bucket bucket = new Bucket();
        Runnable producer = new Producer(bucket);
        Runnable consumer = new Consumer(bucket);

        Thread p = new Thread(producer);
        Thread c = new Thread(consumer);

        /**
         * inner class timer, will count down desired time
         * when count down reaches zero, will then interrupt both producer and consumer thread
         */
        class MyTimer implements Runnable
        {
            private int countDown;
            public MyTimer (int countDown)
            {
                this.countDown = countDown;
            }
            public void run()
            {
                try{
                    while (countDown > 0){
                        System.out.println("Thread Ending in: "+countDown+" second!");
                        Thread.sleep(1000);
                        countDown--;
                    }
                    System.out.println("Thread Ending in: "+countDown+" second!");
                    p.interrupt();
                    c.interrupt();
                }catch(InterruptedException e){

                }finally{

                }
            }
        }
        MyTimer timer = new MyTimer(COUNT_DOWN);
        Thread t = new Thread(timer);

        p.start();
        c.start();
        t.start();
    }
}