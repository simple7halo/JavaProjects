/**
 * CPSC 1181 lab assignment 10
 * practice multi-thread programing
 * @author :Qian Ting Huang
 * student #: 100307328
 * @version :2019-07-23
 */

/**
 * Consumer class, will call median method of the bucket passed in as argument when construct
 * print returned value on screen
 * put to sleep for 2ms
 * repreat while not interrupted
 */
import java.lang.Runnable;

public class Consumer implements Runnable
{
    private Bucket theBucket;

    /**
     * constructor
     */
    public Consumer(Bucket bucket)
    {
        theBucket = bucket;
    }

    /**
     * run method
     * call median method of theBucket
     * print returned value on screen
     * put to sleep for 2ms
     * repeat while not interrupted
     */
    public void run()
    {
        try{ 
            while(true){
                double num = theBucket.median();
                System.out.println(num);
                Thread.sleep(2);
            }
        }catch (InterruptedException e){

        }
        finally{

        }
    }
}