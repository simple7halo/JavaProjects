/**
 * CPSC 1181 lab assignment 10
 * practice multi-thread programing
 * @author :Qian Ting Huang
 * student #: 100307328
 * @version :2019-07-23
 */

/**
 * Producer class, will generate 10 random integer from 0 to 255 and add
 * to a class bucket which passed in as argument when construct
 * then put to sleep for 1ms
 * repeat while not interrupted
 */
import java.lang.Runnable;
import java.util.Random;

public class Producer implements Runnable
{
    private Bucket theBucket;
    private Random rand;
    private final int RANDOM_SIZE = 10;
    private final int RANDOM_BOUND = 256;
    /**
     * constructor
     */
    public Producer(Bucket bucket)
    {
        theBucket = bucket;
        rand = new Random();
    }

    /**
     * run method, will generate 10 random integer from 0 to 255
     * add to theBucket
     * put to sleep for 1ms
     * repeat while not interrupted
     */
    public void run()
    {
        try{
            while (true){
                for (int i=0; i<RANDOM_SIZE; i++){
                int newRand = rand.nextInt(RANDOM_BOUND);
                theBucket.add(newRand);
                }
                Thread.sleep(1);
            }
        }catch (InterruptedException e){

        }
        finally{

        }

    }
}