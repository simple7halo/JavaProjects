/***
 * CPSC 1181 Lab Assignment 7
 * @author Qian Ting Huang(Justin)
 * @version 2019-06-26
 */
/***
 * Circle drawer
 * 1) initialize with first mouse click
 *      a) indicates where the circle's center is
 * 2) moving the mouse will resize the circle 
 *      a) a dash line will be draw from the center to the current mouse position
 *      b) curren mouse position indicates the edge of the circle
 * 3) second mouse click will draw the circle
 *      a) the dash line will disapear
 *      b) will draw a circle with the indicated center
 *      c) radius will be the length of the final dash line
 */

 //library list
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

 //this file is class circle
 public class Circle
 {
    /**
     * instance field
     */
    private double coorX, coorY;
    private double radius;

    /**
     * constructor
     * @param coorX :X coordinate of center of this circle
     * @param coorY :Y coordinate of center of this circle
     */
    public Circle(double coorX, double coorY)
    {   
        this.coorX = coorX;
        this.coorY = coorY;
    }

    //methods
    /**
     * will set the radius
     * @param radius :set the radius of this circle to radius
     */
    public void setRadius(double radius)
    {
        this.radius = radius;
    }

    /**
     * will return the x coordinate of this circle
     * @return :X coordinate of this circle
     */
    public double getX()
    {
        return coorX;
    }

    /**
     * will return the y coordinate of this circle
     * @return :Y coordinate of this circle
     */
    public double getY()
    {
        return coorY;
    }

    public void draw(Graphics2D g2)
    {
        double xTop = coorX-radius;
        double yTop = coorY-radius;
        Ellipse2D.Double c = new Ellipse2D.Double(xTop, yTop, radius*2, radius*2);
        g2.draw(c);
    }
 }