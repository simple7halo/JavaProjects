/***
 * CPSC 1181 Lab Assignment 7
 * @author Qian Ting Huang(Justin)
 * @version 2019-06-26
 */
/***
 * Circle drawer
 * 1) initialize with first mouse click
 *      a) indicates where the circle's center is
 * 2) moving the mouse will resize the circle 
 *      a) a dash line will be draw from the center to the current mouse position
 *      b) curren mouse position indicates the edge of the circle
 * 3) second mouse click will draw the circle
 *      a) the dash line will disapear
 *      b) will draw a circle with the indicated center
 *      c) radius will be the length of the final dash line
 */

 //library list
import javax.swing.JComponent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.awt.BasicStroke;
import java.awt.Color;
import java.util.ArrayList;

/**
 * this file contains the circle componenet which will be included in the main method
 */
 public class CircleComponent extends JComponent
 {
    ArrayList<Circle> circles;
    boolean selected = false;
    Line2D.Double line;
    Circle circleTemp;

     public CircleComponent()
     {
        circles = new ArrayList<Circle>();
        class myMotionListener implements MouseMotionListener
        {
           public void mouseDragged(MouseEvent event){}
            
           public void mouseMoved(MouseEvent event){
               if (selected){
                  double x = event.getX();
                  double y = event.getY();
                  double coorX = circles.get(circles.size()-1).getX();
                  double coorY = circles.get(circles.size()-1).getY();
                  double radius = Math.pow((Math.pow(coorX-x,2)+Math.pow(coorY-y,2)),0.5);
                  circleTemp = new Circle(coorX,coorY);
                  circleTemp.setRadius(radius);
                  line = new Line2D.Double(coorX,coorY,x,y);
                  repaint();
               }
           }
        }

        myMotionListener mouseMotion = new myMotionListener();
        addMouseMotionListener(mouseMotion);
     }

     //methods
     /**
      * returns the selected value, determine if the last indexed circle is selected
      * @return :if last indexed circle is currently selected
      */
     public boolean isSelected(){
         return selected;
     }

     /**
      * changeds the value of seleceted
      */
     public void selectToggle(){
         if (selected) selected = false;
         else selected = true;
     }

     /**
      * will add a circle to the component
      * @param c :the circle which will be added
      */
     public void addCircle(double x, double y)
     {
         Circle c = new Circle(x,y);
         circles.add(c);
     }

     /**
      * will return the last added circle element
      * @return :reference of last added circle element
      */
     public Circle getCircle()
     {
        if (circles.size() == 0) return null;
        else return circles.get(circles.size()-1);
     }

     /**
      * will set the radius of last Circle element in the list
      * @param radius :the raius which will be passed to the last Circle element
      */
     public void setRadius(double radius)
     {
        if (circles.size()>0){
            circles.get(circles.size()-1).setRadius(radius);
        }
        repaint();
     }

     //paint component
     public void paintComponent(Graphics g)
     {
        //recover graphis 2d
        Graphics2D g2 = (Graphics2D) g;
        Color color;

        //draw
        if (!circles.isEmpty()){
           color = Color.BLUE;
           g2.setStroke(new BasicStroke(3));
            for (Circle c: circles){
               g2.setColor(color);
               c.draw(g2);
            }
        }

        if (selected) {
            color = Color.RED;
            g2.setColor(color);
            g2.setStroke(new BasicStroke(1));
            circleTemp.draw(g2);
            BasicStroke dashed = new BasicStroke(1, BasicStroke.CAP_BUTT, 
            BasicStroke.JOIN_BEVEL, 0, new float[]{6}, 0);
            g2.setStroke(dashed);
            g2.draw(line);

        }

     }
 }