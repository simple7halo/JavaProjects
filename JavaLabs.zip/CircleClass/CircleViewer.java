/***
 * CPSC 1181 Lab Assignment 7
 * @author Qian Ting Huang(Justin)
 * @version 2019-06-26
 */
/***
 * Circle drawer
 * 1) initialize with first mouse click
 *      a) indicates where the circle's center is
 * 2) moving the mouse will resize the circle 
 *      a) a dash line will be draw from the center to the current mouse position
 *      b) curren mouse position indicates the edge of the circle
 * 3) second mouse click will draw the circle
 *      a) the dash line will disapear
 *      b) will draw a circle with the indicated center
 *      c) radius will be the length of the final dash line
 */

 //library list
import javax.swing.JFrame;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

 //this file contains the frame
public class CircleViewer
{
    //main method
    public static void main(String[] args)
    {
        final CircleComponent circleCompon = new CircleComponent();
        final int FRAME_WIDTH = 1024;
        final int FRAME_HEIGHT = 768;

        class MyMouseListener implements MouseListener
        {
            public void mouseClicked(MouseEvent event)
            {
                if (!circleCompon.isSelected()){
                    double x = event.getX();
                    double y = event.getY();
                    circleCompon.addCircle(x,y);
                    circleCompon.selectToggle();
                }
                else{
                    double x = event.getX();
                    double y = event.getY();
                    double selectX = circleCompon.getCircle().getX();
                    double selectY = circleCompon.getCircle().getY();
                    double radius = Math.pow((Math.pow(selectX-x,2)+Math.pow(selectY-y,2)),0.5); 
                    circleCompon.setRadius(radius);
                    circleCompon.selectToggle();
                }
            }
            public void mouseReleased(MouseEvent event){}
            public void mousePressed(MouseEvent event){}
            public void mouseEntered(MouseEvent event){}
            public void mouseExited(MouseEvent event){}

        }

        JFrame frame = new JFrame();

        MyMouseListener mouseListen = new MyMouseListener();
        circleCompon.addMouseListener(mouseListen);

        frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        frame.setTitle("Circle Drawer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        frame.add(circleCompon);

        frame.setVisible(true);

    }
}