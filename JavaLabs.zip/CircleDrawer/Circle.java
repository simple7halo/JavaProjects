/**
 * CPSC 1181 Lab Assignment 8
 * @author Qian Ting Huang
 * Student #: 100307328
 * @version 2019-7-9
 * Description: Drawing panel for colored circles
 */
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.lang.Comparable;

/**
 * Circle class: create a circle with input coordinate and radius
 */
public class Circle implements Comparable<Circle>
{  
   private Ellipse2D.Double c;
   private int xDir;
   private double r;
   
   /**
    * constructor: create a circle with input coordinate and radius
    * @param x :x coordinate
    * @param y :y coordinate
    * @param r :radius of the circle
    */
   public Circle(double x, double y, double r)
   {
      this.r = r;
      xDir = 1;
      c = new Ellipse2D.Double(x-r, y-r, 2*r, 2*r);
   }

   /**
    * moveTo method: move this circle to input coordinate
    * @param x :destination x coordinate
    * @param y :destination y coordinate
    */
   public void moveTo(double x, double y){
      c.setFrame(x, y, c.getWidth(), c.getHeight());
   }
   
   /**
    * move the circle inside the input border if it is outside of it
    * @param width :border width
    */
   public void move(int width){
      if(c.getX()+c.getWidth()>width)
         xDir = xDir * -1;
      c.setFrame(c.getX()+2*xDir, c.getY(),c.getWidth(),c.getHeight());
   }

   /**
    * getR method: returns radius of this circle
    * @return :radius of this circle
    */
   public double getR(){
      return r;
   }

   @Override
   public int compareTo(Circle otherCircle){
      if (this.r < otherCircle.r)
         return 1;
      if (this.r > otherCircle.r)
         return -1;
      return 0;
   }

   /**
    * draw this circle
    * @param g2 :pen
    */
   public void draw(Graphics2D g2)
   {
	   g2.fill(c);
   }	   
}
