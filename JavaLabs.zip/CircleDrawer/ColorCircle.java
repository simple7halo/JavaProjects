/**
 * CPSC 1181 Lab Assignment 8
 * @author Qian Ting Huang
 * Student #: 100307328
 * @version 2019-7-9
 * Description: Drawing panel for colored circles
 */
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

/**
 * ColorCircle class: create a circle with random color
 */
public class ColorCircle extends Circle{
    private Color color;
    
    /**
     * constructor: creates a circle with coordinate and radius as input and a random color
     * @param x :x coordinate
     * @param y :y coordinate
     * @param r :radius of the circle
     */
    public ColorCircle(double x, double y, double r){
        super(x,y,r);
        Random rand = new Random();
        int red, green, blue;
        red = rand.nextInt(256);
        green = rand.nextInt(256);
        blue = rand.nextInt(256);
        color = new Color(red,green,blue);
    }

    /**
     * draw this circle with random color
     * @param g2 :pen
     */
    public void fill(Graphics2D g2){
        // draw and fill the circle with myColor
        g2.setColor(color);
        super.draw(g2);
    }
}