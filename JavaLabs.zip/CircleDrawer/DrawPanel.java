/**
 * CPSC 1181 Lab Assignment 8
 * @author Qian Ting Huang
 * Student #: 100307328
 * @version 2019-7-9
 * Description: Drawing panel for colored circles
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collections;

/**
 * draw panel that will draw circles
 * include all displaying circles stored as arraylist
 */
public class DrawPanel extends JPanel{
   ArrayList<ColorCircle> circles;

   /**
    * constructor
    */
   public DrawPanel(){
       circles = new ArrayList<ColorCircle>();
   }

   /**
    * addCircle method: will add a circle with input coordinate and radius
    * @param x: x-coordinate
    * @param y: y-coordinate
    * @param r: radius of the circle
    */
   public void addCircle(double x, double y, double r){
      circles.add(new ColorCircle(x,y,r));
      // call reapint from the JPanel
      repaint();
   }

   /**
    * reset method: will clear all the circles in the draw panel as well as the array list
    */
   public void reset(){
      while(circles.size()>0){
         circles.remove(0);
      }
   }

   /**
    * sort method: will sort all the circles displaying according to radius so all of them can be displayed
    */
   public void sort(){
      Collections.sort(circles);
   }

   /**
    * move method: will move all the circles displaying to center of this panel
    */
   public void move(){
      for (ColorCircle c: circles)
         c.moveTo(getWidth()/2-c.getR(),getHeight()/2-c.getR());
   }

   /**
    * draws all the circles stored in the array list
    */
   public void paintComponent(Graphics g)
   {  
      // Important call super.paintComponent(g) first in this case
      // Be carful not to fall in recursion
      super.paintComponent(g);
      Graphics2D g2 = (Graphics2D) g;
      for(ColorCircle c : circles)
         c.fill(g2);
    
     
   }
}