/**
 * CPSC 1181 Lab Assignment 8
 * @author Qian Ting Huang
 * Student #: 100307328
 * @version 2019-7-9
 * Description: Drawing panel for colored circles
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.util.Random;

/**
 * Main Panel includes all other panels
 * Panels:  drawPanel - description in class file
 *          dataPanel - include input text fields
 *          buttonPanel - include all buttons
 */
public class MainPanel extends JPanel{
   DrawPanel drawPanel;
   JPanel dataPanel,buttonPanel;
   Random rand;
   JTextField numberOfCircle = new JTextField("5",10);
   JTextField smallRadius = new JTextField("10",10);
   JTextField largeRadius = new JTextField("300",10);
   
   /**
    * constructor: creates a main panel and add everything to it
    */
   public MainPanel(){
      rand = new Random();
      setLayout(new BorderLayout());
      buttonPanel = new JPanel();
     
      buttonPanel.setLayout(new GridLayout(4,1));
      JButton button1 = addButton("Create");
      JButton button4 = delButton("Reset");
      JButton button2 = sortButton("Sort");
      JButton button3 = coButton("Co-Centre");
      
      buttonPanel.add(button1);
      buttonPanel.add(button2);
      buttonPanel.add(button3);
      buttonPanel.add(button4);
      
      add(buttonPanel, BorderLayout.WEST); 
      
      dataPanel = new JPanel();
      dataPanel.add(new JLabel("Number of Cirles: "));
      dataPanel.add(numberOfCircle);
      dataPanel.add(new JLabel("Radius of smallest circle: "));
      dataPanel.add(smallRadius);
      dataPanel.add(new JLabel("Radius of largest circle: "));
      dataPanel.add(largeRadius);
      add(dataPanel, BorderLayout.NORTH);

      drawPanel = new DrawPanel();
      add(drawPanel, BorderLayout.CENTER); 
   }
   /**
    * addButton class: creates number of circles with range of radius and random coordinate
    * number of circles and range of radius will be read from textfields in data panel
    * @param title :text displayed on the button
    * @return :return this button created
    */
   private JButton addButton(String title){   
      class CreateListener implements ActionListener
      {
         public void actionPerformed(ActionEvent event)
         {
            int w = getWidth();
            int h = getHeight();
            int small = Integer.parseInt(smallRadius.getText());
            int large = Integer.parseInt(largeRadius.getText());
            int n = Integer.parseInt(numberOfCircle.getText());
            for (int i=0; i<n; i++)
               drawPanel.addCircle(rand.nextInt(w/2),rand.nextInt(h/2),rand.nextInt(large)+small);
           
         }            
      }
      JButton button = new JButton(title);
      button.addActionListener(new CreateListener());
      return button;
   }

   /**
    * delButton class: deletes all circles displaying and reset draw panel
    * @param title :text displayed on button
    * @return :this button created
    */
   private JButton delButton(String title){   
      class DeleteListener implements ActionListener
      {
         public void actionPerformed(ActionEvent event)
         {
            drawPanel.reset();
            // Call repaint from outside.
            // Its effect is the same as call it from drawPanel
            drawPanel.repaint();
         } 

      }
      JButton button = new JButton(title);
      button.addActionListener(new DeleteListener());
      return button;
   }

   /**
    * sortButton class: sort all circles displaying according to radius so they can all be displayed
    * @param title :text displayed on button
    * @return :this button created
    */
   private JButton sortButton(String title){   
      class SortListener implements ActionListener
      {
         public void actionPerformed(ActionEvent event)
         {
            drawPanel.sort();
            // Call repaint from outside.
            // Its effect is the same as call it from drawPanel
            drawPanel.repaint();
         } 

      }
      JButton button = new JButton(title);
      button.addActionListener(new DeleteListener());
      return button;
   }

   /**
    * coButton class: moves all circles displaying to the center of draw panel
    * @param title :text displayed on button
    * @return :this button created
    */
   private JButton coButton(String title){   
      class CoListener implements ActionListener
      {
         public void actionPerformed(ActionEvent event)
         {
            drawPanel.move();
            // Call repaint from outside.
            // Its effect is the same as call it from drawPanel
            drawPanel.repaint();
         } 

      }
      JButton button = new JButton(title);
      button.addActionListener(new DeleteListener());
      return button;
   }

}