/**
 * CPSC 1181 Lab Assignment 8
 * @author Qian Ting Huang
 * Student #: 100307328
 * @version 2019-7-9
 * Description: Drawing panel for colored circles
 */
import javax.swing.JFrame;

/**
*   This program displays the growth of an investment. 
*/
public class Program
{  
  public static void main(String[] args)
  {  
    JFrame frame = new JFrame();
    frame.add(new MainPanel());

    frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }
  private static final int FRAME_WIDTH = 800;
  private static final int FRAME_HEIGHT = 800;
}
   