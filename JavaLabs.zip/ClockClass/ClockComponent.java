/*
CPSC 1181 Lab Assignment 3
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: ClockComponent.java
Description: Clock Component class for the Clock GUI

*@author Qian Ting Huang
*@version 2019-06-03
*/

import javax.swing.JComponent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.time.LocalDateTime;

public class ClockComponent extends JComponent
{
    MyClock clock;
    int hour, minute, second;

    /**
     * Paint area.
     */
    public void paintComponent(Graphics g)
    {
        //recover graphics 2d
        Graphics2D g2 = (Graphics2D) g;

        clock = new MyClock(getWidth() * 1.0, getHeight() * 1.0);

        LocalDateTime now = LocalDateTime.now();
        hour = now.getHour()%12;
        minute = now.getMinute();
        second = now.getSecond();

        clock.setTime(hour, minute, second);

        //draw clock
        clock.draw(g2);
    }
}