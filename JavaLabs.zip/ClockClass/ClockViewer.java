/*
CPSC 1181 Lab Assignment 3
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: ClockViewer.java
Description: Viewer class of the clock GUI

*@author Qian Ting Huang
*@version 2019-06-03
*/

import javax.swing.JFrame;
public class ClockViewer
{
    /***
     * main method, creating JFrame
     * @param args
     */
    public static void main(String[] args)
    {
        JFrame frame = new JFrame();

        final int width = 400;
        final int height = 400;

        frame.setSize(width, height);
        frame.setTitle("Clock");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ClockComponent clock = new ClockComponent();
        frame.add(clock);

        frame.setVisible(true);
    }
}