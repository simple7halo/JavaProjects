/*
CPSC 1181 Lab Assignment 3
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: MyClock.java
Description: The Clock itself of the Clock GUI.

*@author Qian Ting Huang
*@version 2019-06-03
*/

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.Color;

/**
 *  A Clock class that will display time. 
 */
public class MyClock
{
    /**
     * properties: 
     */
    public static final double PI = 3.14;
    private int hour, minute, second;
    private double width, x, y;
   
    /**
     * Constructor with size of the screen
     * @param screenWidth width of the display area
     * @param screenHeight height of the display area
     */
    public MyClock(double screenWidth, double screenHeight)
    {
        hour = 0;
        minute = 0;
        second = 0;

        if (screenWidth > screenHeight) 
            width = screenHeight * 0.9;
        else width = screenWidth * 0.9;

        x = (screenWidth - width) /2;
        y = (screenHeight - width) /2;
    }

    /**
     * Changes the time displaying
     * @param hour the hour of current time
     * @param minute the minute of current time
     * @param second the second of current time
     */
    public void setTime(int hour, int minute, int second)
    {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    /**
     * draw method to display the clock
     * @param g2
     */
    public void draw(Graphics2D g2)
    {
        //value store for handles
        double toX, toY, lengthScale, radian, hour, minute;
        final double radius = width/2;
        final int centerScale = 20; //scale of how small the center should be

        //the outer circle boarder
        Ellipse2D.Double outer = new Ellipse2D.Double(x, y, width, width);
        g2.setStroke(new BasicStroke((float)(width/45)));
        g2.setColor(new Color(180, 180, 180));
        g2.draw(outer);

        //indicate period of time
        //15 mins mark
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke((float)(width/90)));
        Line2D.Double min0 = new Line2D.Double(x+radius, y+radius/centerScale*2, x+radius, y+radius/centerScale);
        Line2D.Double min15 = new Line2D.Double(x+width-radius/centerScale, y+radius, x+width-radius/centerScale*2, y+radius);
        Line2D.Double min30 = new Line2D.Double(x+radius, y+width-radius/centerScale, x+radius, y+width-radius/centerScale*2);
        Line2D.Double min45 = new Line2D.Double(x+radius/centerScale*2, y+radius, x+radius/centerScale, y+radius);
        g2.draw(min0);
        g2.draw(min15);
        g2.draw(min30);
        g2.draw(min45);

        //5mins mark
        g2.setStroke(new BasicStroke((float)(width/180)));
        lengthScale = 1-1.0/centerScale; //the scale of radius

        for (int degree = -60; degree < 270; degree+=30){
            if (degree == 0||degree == 90||degree == 180)   continue;
            
            radian = Math.toRadians(degree);
            Line2D.Double min5 = new Line2D.Double
            (x+radius+radius*lengthScale*Math.cos(radian), y+radius+radius*lengthScale*Math.sin(radian),
            x+radius+radius*lengthScale*lengthScale*Math.cos(radian), y+radius+radius*lengthScale*lengthScale*Math.sin(radian));
            g2.draw(min5);
        }

        //1mins mark of time
        for (int degree = -84; degree < 270; degree+=6){
            if (degree == 0||degree == 90||degree == 180)   continue;
            
            radian = Math.toRadians(degree);
            Line2D.Double min5 = new Line2D.Double
            (x+radius+radius*lengthScale*Math.cos(radian), y+radius+radius*lengthScale*Math.sin(radian),
            x+radius+radius*lengthScale*Math.cos(radian), y+radius+radius*lengthScale*Math.sin(radian));
            g2.draw(min5);
        }

        //small red circle at the center
        Ellipse2D.Double center = new Ellipse2D.Double(x+radius-radius/centerScale, y+radius-radius/centerScale, width/centerScale, width/centerScale);
        g2.setColor(Color.RED);
        g2.fill(center);

        //draw string
        g2.setColor(Color.BLACK);
        g2.setFont(new Font("TimesRoman", Font.PLAIN, (int)(width/18)));
        g2.drawString("CPSC1181", (int)(x+radius*3/4), (int)(y+radius/2));

        //second handle
        radian = (second/60 * 2 * PI)-PI/2; //get radian angle
        lengthScale = 0.8; //length of the handle
        toX = x + radius + (radius*lengthScale*Math.cos(radian));
        toY = y + radius + (radius*lengthScale*Math.sin(radian));
        Line2D.Double secondHandle = new Line2D.Double(x+radius, y+radius, toX, toY);
        g2.setStroke(new BasicStroke((float)(width/110)));
        g2.setColor(Color.RED);
        g2.draw(secondHandle);

        //minute handle
        minute = this.minute + (second/60.0); //get the actual minute value in decimal place
        radian = (minute/60 * 2 * PI)-PI/2;
        lengthScale = 0.65; //length of the handle
        toX = x + radius + (radius*lengthScale*Math.cos(radian));
        toY = y + radius + (radius*lengthScale*Math.sin(radian));
        Line2D.Double minuteHandle = new Line2D.Double(x+radius, y+radius, toX, toY);
        g2.setStroke(new BasicStroke((float)(width/60)));
        g2.setColor(Color.BLACK);
        g2.draw(minuteHandle);

        //hour handle
        hour = this.hour + (minute/60.0); //get the actual hour value in decimal place
        radian = (hour/12 * 2 * PI)-PI/2;
        lengthScale = 0.50; //length of the handle
        toX = x + radius + (radius*lengthScale*Math.cos(radian));
        toY = y + radius + (radius*lengthScale*Math.sin(radian));
        Line2D.Double hourHandle = new Line2D.Double(x+radius, y+radius, toX, toY);
        g2.setStroke(new BasicStroke((float)(width/40)));
        g2.setColor(Color.BLACK);
        g2.draw(hourHandle);

    }

    @Override
    public String toString()
    {
        return "[x:"+x+", y:"+y+", w:"+width
        +", time:"+hour+":"+minute+":"+second+"]";
    }
}