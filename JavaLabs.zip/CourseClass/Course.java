/*
CPSC 1181 Lab Assignment 2
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: Course.java
Description: A class Course
Properties:
   Students
   course name
   
Method:
   add student to course
   find student in course
   remove student from course
   add quiz
   find student with highest grade
   get course average

*@author Qian Ting Huang
*@version 2019-05-26
*/

import java.util.ArrayList;
public class Course{
   /**
    * properties
    */
   private ArrayList<Student> students; //the students in the course
   private String courseName; //the course name

   /**
    * creates a course, with a course name assigned to it
    */
   public Course(String courseName)
   {
      this.courseName = courseName;
      students = new ArrayList<Student>();
   }

   /**
    * add a student to the course
    * @param name name of the student
    * @param familyNamy family name of the student
    * @return reference of the student
    */
   public Student addStudent (String name, String familyName)
   {
      Student s = new Student(name, familyName);
      students.add(s);
      return s;
   }

   /**
    * search for an exsisting student in the course
    * @param studentId the student id searching for
    * @return the student, if not found, return null
    */
   public Student findStudent (long studentId)
   {
      for (Student s:students)
      {
         if (s.getStudentNumber() == studentId) return s;
      }
      return null;
   }

   /**
    * delete a student from the course
    * @param studentId the student number of student who is going to be deleted
    * @return the deleted student, or if not found, return null
    */
   public Student deleteStudent (long studentId)
   {
      for (int i = 0; i < students.size(); i++)
      {
         if (students.get(i).getStudentNumber() == studentId)
         {
            Student s = students.get(i);
            students.remove(i);
            return s;
         }
      }
      return null;
   }

   /**
    * add a quiz to a student
    * @param studentId the student number of that student
    * @param scale the scale of the quiz being added
    * @param studentGrade the grade student achieve in this quiz
    * @return true if success, otherwise false
    */
   public boolean addQuiz (long studentId, double scale,  double studentGrade)
   {
      if (findStudent(studentId) != null) 
      {
         Student s = findStudent(studentId);
         s.addQuiz(scale, studentGrade);
         return true;
      }
      else return false;
   }

   /**
    * find the student with highest average quiz grades
    * @return student with highest average quiz, if not found then return null
    */
   public Student findTopStudent()
   {
      if (students.size() <= 0) return null;
      else 
      {
         Student topStudent = students.get(0);
         double max = students.get(0).getQuizAverage();
         for (Student s: students)
         {
            if (s.getQuizAverage() > max)
            {
               topStudent = s;
               max = topStudent.getQuizAverage();
            }
         }
         return topStudent;
      }
   }

   /**
    * find the course average quiz grade
    * @return the average quiz grade of the course
    */
   public double getAverage()
   {
      if (students.size() <= 0) return 0;
      else 
      {
         double quizTotal = 0;
         for (Student s: students)
         {
            quizTotal += s.getQuizAverage();
         }
         return quizTotal * 10 / students.size();
      }
   }

   @Override
   public String toString()
   {
      String output = "[Course Name: ";
      output += courseName;
      output += "]\n[Course Average: ";
      output += getAverage();
      output +="]\n[Number of Students: ";
      output += students.size();
      output += "]";

      return output;
   }
}
