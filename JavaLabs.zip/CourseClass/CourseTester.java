/*
CPSC 1181 Lab Assignment 2
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: CourseTester.java
Description: Test case for class Student

*@author Qian Ting Huang
*@version 2019-05-26
*/

class CourseTester{
    public static Student student; //for test case student class
    public static Course course; //for test case course class
	public static void main(String[] args){
        //student class test cases
        System.out.println("Test Case for Student Class: ");

        //test student construtor
        testConstructor("Marry", "jones");

		// test Student getName, geyStudentNumber(), getLoginId()
		testGetName();
        
		testGetStudentNumber();
        
		testGetLogId();


		// test Student getInfo()
		testGetInfo();

		// test Student addQuiz and getAverage
		testAddQuiz(10, 6.0);
		testAddQuiz(10, 8.5);
		testAddQuiz(10, 9.8);
		
		//test student setName
        testSetName("Not", "Marry");
        
        //course class test cases
        System.out.println("Test Case for Course Class: ");

        //test course constructor
        testCourseConstructor("CPSC 1181");
        
        //test course add student
        testCourseStudent("Student", "Add");
        testCourseStudent("Student", "Find");
        testCourseStudent("Student", "Remove");

        //test course find student
        testCourseFind(10000003);

        //test course add quiz 
        testCourseQuiz(10000003, 10, 6.5);
        testCourseQuiz(10000004, 10, 8.5);
        testCourseQuiz(10000003, 10, 9.5);
        testCourseQuiz(10000004, 10, 4.5);

        //test course remove student
        testCourseRemove(10000004);


    }
    
    /**
     * test student class constructor
     * @param name name of student creating
     * @param familyName family name of student creating
     */
    public static void testConstructor(String name, String familyName)
    {
        student = new Student(name,familyName);
		System.out.println("Test student constructor:");
		System.out.println(student); 
        System.out.println("");
    }

    /**
     * test the get name method of student class
     */
    public static void testGetName()
    {
        System.out.println("Test getName:");
        System.out.println(student.getName());
    }

    /**
     * test the get student number method of student class
     */
    public static void testGetStudentNumber()
    {
        System.out.println("\nTest getStudentNumber:");
        System.out.println(student.getStudentNumber());
    }

    /**
     * test the get login id method of student class
     */
    public static void testGetLogId()
    {
        System.out.println("\nTest getLoginId:");
		System.out.println(student.getLoginId());
		System.out.println("");
    }

    /**
     * test the get info method of student class
     */
    public static void testGetInfo()
    {
        System.out.println("Test getInfo:");
		System.out.println(student.getInfo());
		System.out.println("");
    }

    /**
     * test the add quiz method of student class
     * @param scale the scale of that quiz
     * @param grade the grade of that quiz
     */
    public static void testAddQuiz(double scale, double grade)
    {
        System.out.println("Test addQuiz and getAverage:");
		student.addQuiz(scale, grade);
		System.out.println(student.getQuizAverage());
		System.out.println("");
    }

    /**
     * test the set name method of the student class
     * @param name new name of the student
     * @param familyName new family name for the student
     */
    public static void testSetName(String name, String familyName)
    {
        System.out.println("Test setName:");
		student.setName(name, familyName);
		System.out.println(student.getInfo());
		System.out.println("");
    }

    /**
     * test the course class constructor
     * @param courseName the name of the course
     */
    public static void testCourseConstructor(String courseName)
    {
        course = new Course(courseName);
        System.out.println("Test course constructor:");
		System.out.println(course); 
		System.out.println("");
    }

    /**
     * test the add student method for course class
     * @param name
     * @param familyName
     */
    public static void testCourseStudent(String name, String familyName)
    {
        System.out.println("Test course add student:");
        System.out.println(course.addStudent(name, familyName));
        System.out.println(course); 
    }

    /**
     * test course find student method
     * @param studentId the student number of the student is being searched for
     */
    public static void testCourseFind(long studentId)
    {
        System.out.println("Test course find student:");
        System.out.println(course.findStudent(studentId));
        System.out.println(course); 
    }

    /**
     * test course remove student method
     * @param studentId student number of the student who will be removed
     */
    public static void testCourseRemove(long studentId)
    {
        System.out.println("Test course remove student:");
        System.out.println(course.deleteStudent(studentId));
        System.out.println(course); 
    }

    /**
     * test course add quiz method
     * @param studentId student number of the student who will be added quiz on
     * @param scale the scale of the quiz which will be added
     * @param grade the grade this student achieved in this quiz
     */
    public static void testCourseQuiz(long studentId, double scale, double grade)
    {
        System.out.println("Test Course addQuiz and getAverage:");
		System.out.println(course.addQuiz(studentId, scale, grade));
		System.out.println(course.getAverage());
		System.out.println("");
    }

}