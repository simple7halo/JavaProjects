/*
CPSC 1181 Lab Assignment 2
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: Quiz.java
Description: A class Quiz
Properties:
   scale: quiz scale
   studentGrade: the grade student achieved in the quiz

Method:
   return scale
   return grade
*@author Qian Ting Huang
*@version 2019-05-26
*/

public class Quiz
{
   /**
    * properties
    */
   private double scale; //scale of the quiz
   private double studentGrade; //the grae student achieved in the quiz

   /**
    * not passing values will give 0 scale 0 grade by default 
    */
   public Quiz()
   {
      scale = 0;
      studentGrade = 0;
   }

   /**
    * create a quiz, a quiz has scale and studentGrade
    */
   public Quiz(double scale, double studentGrade)
   {
     this.scale = scale;
     this.studentGrade = studentGrade;
   }

   /**
    * get the quiz's scale
    * @return scale of this quiz
    */
   public double getScale()
   {
      return scale;
   }

   /**
    * get the grade of this quiz
    * @return grade of this quiz
    */
   public double getGrade()
   {
      return studentGrade;
   }

   @Override 
   public String toString()
   {
      String output = "(Scale: ";
      output += getScale();
      output += ", Grade: ";
      output += getGrade();
      output += ")";

      return output;
   }
}