/*
CPSC 1181 Lab Assignment 2
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: CourseRunner.java
Description: Runner program for Course class 
takes input from user
provide corresponding output

*@author Qian Ting Huang
*@version 2019-05-26
*/

import java.util.Scanner;
public class CourseRunner
{
    public static Course course = new Course("CPSC 1181");
    //main method
    public static void main(String[] args)
    {
        int inputs;
        Scanner input = new Scanner(System.in);
        do{
            System.out.println("Course directory commands: ");
            System.out.println("1. add a new Student");
            System.out.println("2. find Student");
            System.out.println("3. delete Student");
            System.out.println("4. add quiz");
            System.out.println("5. find student with the highest quiz score");
            System.out.println("6. get course average");
            System.out.println("7. quit");
            System.out.print("select option: ");

            inputs = input.nextInt();

            switch (inputs)
            {
                case 1: add(); break;
                case 2: find(); break;
                case 3: delete(); break;
                case 4: addQuiz(); break;
                case 5: findTop(); break;
                case 6: average(); break;
                default: break;
            }

        }while(inputs != 7);
        
        
    }

    /**
     * add new student
     */
    public static void add()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Add a new Student:");
        System.out.print("Student's name:");
        String name = input.nextLine();
        System.out.print("Student's surname:");
        String surName = input.nextLine();
        Student s = course.addStudent(name, surName);
        if (s != null)
        {
            System.out.println("Student added: ");
            System.out.println(s.getInfo() + "\n");
        }
        else System.out.println("Student not Added!\n");
    }

    /**
     * find a student
     */
    public static void find()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Find Student:");
        System.out.print("Student's number(id):");
        long id = input.nextLong();
        Student s = course.findStudent(id);
        if (s != null)
        {
            System.out.println("Student found: ");
            System.out.println(s.getInfo() + "\n");
        }
        else System.out.println("Student not found!\n");
    }

    /**
     * delete a student
     */
    public static void delete()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Delete a Student:");
        System.out.print("Student's number(id):");
        long id = input.nextLong();
        Student s = course.deleteStudent(id);
        
        if (s != null)
        {
            System.out.println("Student deleted: ");
            System.out.println(s.getInfo() + "\n");
        }
        else System.out.println("Student not found!\n");
    }

    /**
     * add quiz to a student
     */
    public static void addQuiz()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("\nAdd a quiz to Student:");
        System.out.print("Student's number(id):");
        long id = input.nextLong();
        Student s = course.findStudent(id);
        if (s == null) System.out.println("Student not found!\n");
        else
        {
            System.out.print("Quiz's Scale: ");
            double scale = input.nextDouble();
            System.out.print("Quiz's Grade: ");
            double grade = input.nextDouble();

            if (course.addQuiz(id, scale, grade))
            {
                System.out.println("Quiz added:");
                System.out.println("Student's new average: " + s.getQuizAverage() + "\n");
            }
            else System.out.println("Error! Quiz unsuccessfully added!\n");
        }
    }

    /**
     * find student with highest quiz grade
     */
    public static void findTop()
    {
        System.out.println("Find the top Student:");
        System.out.print("Student's number(id):");
        
        if (course.findTopStudent() == null) System.out.println("Empty class!\n");
        else
        {
            Student s = course.findTopStudent();
            System.out.println("Top student quiz score: " + s.getQuizAverage());
            System.out.println("Top student's student number: " + s.getStudentNumber() + "\n");
        }
    }

    /**
     * get course average quiz grade
     */
    public static void average()
    {
        System.out.println("Find course average grade: ");
        System.out.println("Course average grade: " + course.getAverage() + "\n");
    }
}