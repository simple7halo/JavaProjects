/*
CPSC 1181 Lab Assignment 2
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: Student.java
Description: A class Student
Properties:
   Name and Surname
   Student Number
   quiz's countain student quiz info
   Student number which is assigned by the system
   Login id that is assigned "by the system" when the student is constructed
*@author Qian Ting Huang
*@version 2019-05-26
*/

import java.util.ArrayList;
public class Student
{
	/**
		Properties
	*/
	private String firstName, surName; //student's name and surname
	private long studentNumber; //student's student number
	private ArrayList<Quiz> quiz; //student's quiz
	private String studentId; //student login id
	//static variables
	private static long count = 10000001; //use to assign student number
	   
	/**
		Creates a student
		A student have first name and surname
		student number is assigned by system
	*/
	public Student(String firstName, String surName){
		this.firstName = firstName;
		this.surName = surName;
		studentNumber = count;
		count ++; //increment student count for student number of next student
		generateId(); //generate student Id
		//initialize student's quiz
		quiz = new ArrayList<Quiz>();
	}
	
	/**
		generate student's login Id
	*/
	public void generateId(){
		studentId = "";
		//take first letter of first name and switch to lower case if needed
		if ((firstName.charAt(0) >= 'A') && (firstName.charAt(0) <= 'Z'))
			studentId += (char)(firstName.charAt(0) - 'A' + 'a');
		else
			studentId += firstName.charAt(0);
		
		if (surName.length() <= 4) studentId += surName;
		else studentId += surName.substring(0, 4);
		//get the last two digit of student number
		String num = "" + studentNumber;
		num = num.substring(num.length()-2);
		studentId += num;
	}
	
	/**
		set student's name and surname. Changing student's name does not affect the
		students's loginId
		@param firstName: first name of student
		@param surName: last name of student
	*/
	public void setName(String firstName, String surName){
		this.firstName = firstName;
		this.surName = surName;
	}
	
	/**
		returns name and surname separated by comma
		@return the name of the student
	*/
	public String getName(){
		String name = "";
		name += firstName;
		name += ", ";
		name += surName;
		return name;
	}
	
	/**
		returns student number
		@return the student's student number
	*/
	public long getStudentNumber(){
		return studentNumber;
	}
	
	/**
		returns the students login Id
		return: the login Id of the student
	*/
	public String getLoginId(){
		return studentId;
	}
	
	/**
		returns student's info with following format
		name, surname (student number, Student login in) <<< this is the format in test case
		@return general information about the student in a certain format
	*/
	public String getInfo(){
		String info = "";
		info += getName();
		info += "(";
		info += getStudentNumber();
		info += ", ";
		info += getLoginId();
		info += ")";
		return info;
	}
	
	/**
		add a quiz score to the student
		@param quiz: the quiz score that will be added into student's quiz's record
	*/
	public void addQuiz(double scale, double grade){
		quiz.add(new Quiz(scale, grade));
	}

	/**
	 * get the average quiz score of the studen
	 */
	public double getQuizAverage()
	{
		if (quiz.size() == 0) return 0;
		double scaleTotal = 0;
		double grade = 0;
		//get total scale point and number of quiz
		for (Quiz q: quiz)
		{
			scaleTotal += q.getScale();
		}

		//calculate total quiz score
		for (Quiz q: quiz)
		{
			grade += q.getGrade() * (q.getScale()/scaleTotal);
		}

		return grade;
	}
	
	@Override
	public String toString(){
		String output = "[";
		output += getName();
		output += ", ";
		output += getStudentNumber();
		output += ", ";
		output += getLoginId();
		output += "]";
		// complete information for toString method
		output += "]\n[Quiz Average: ";
		output += getQuizAverage();
		output += "]";
		
		return output;
		
	}
	
}