/**
 * CPSC 1181 Lab Assignment 9
 * @author :Qian Ting Huang
 * student#: 100307328
 * @version :2019-07-16
 */

import java.lang.RuntimeException;

/**
 * possible pre-defined exceptions
 */
public class CPSC1181Exception extends RuntimeException
{
    public CPSC1181Exception(String msg)
    {
        super(msg);
    }
    
}