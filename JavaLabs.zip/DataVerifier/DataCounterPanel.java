/**
 * CPSC 1181 Lab Assignment 9
 * @author :Qian Ting Huang
 * student#: 100307328
 * @version :2019-07-16
 */

import javax.swing.JPanel;
import java.lang.NumberFormatException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

/**
 * the DataCounterPanel includes the main panel of the program
 * will also handle all exceptions
 */
public class DataCounterPanel extends JPanel
{
    private DataVerifier dataVerifier;
    private JTextField data1, data2;
    private JLabel lab1, lab2;
    private JButton button;
    
    /**
     * constructor: creates a data counter panel
     */
    public DataCounterPanel()
    {
        dataVerifier = new DataVerifier();
        data1 = new JTextField("1/12/2000");
        data1.setFont(new Font(Font.MONOSPACED, Font.BOLD, 24));
        data2 = new JTextField("7/11/2016");
        data2.setFont(new Font(Font.MONOSPACED, Font.BOLD, 24));
        lab1 = new JLabel("Start Date: ");
        lab1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        lab2 = new JLabel("End Date: ");
        lab2.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        button = countButton("count");

        setLayout(new GridLayout(1, 5));
        add(lab1);
        add(data1);
        add(lab2);
        add(data2);
        add(button);
    }

    /**
     * will generate output for display to user
     * @param date1 :the starting date 
     * @param date2 :the end date
     * @return :the output as string
     */
    private String getOutput(LocalDate date1, LocalDate date2)
    {   
        String output;
        if (date1.compareTo(date2) > 0) throw new DateTimeException("Start date must be before the End date!");
        long totalDays = ChronoUnit.DAYS.between(date1, date2);
        Period duration = Period.between(date1,date2);
        int days = duration.getDays();
        int month = duration.getMonths();
        int year = duration.getYears();
        if (totalDays == 0){
            output = "time did not passed!";
        }else output = ""+days+" days\n"+month+" months\n"+year+" years\n"+totalDays+" total days!";
        return output;
    }

    /**
     * private method for creating count button
     * @param title :text displayed on the button
     * @return :the button reference
     */
    private JButton countButton(String title)
    {
        class countListener implements ActionListener
        {
            public void actionPerformed(ActionEvent event)
            {
                try{
                    LocalDate date1 = dataVerifier.verify(data1.getText());
                    LocalDate date2 = dataVerifier.verify(data2.getText());
                    String output = getOutput(date1, date2);
                    JOptionPane.showMessageDialog(null, output, "Message", JOptionPane.INFORMATION_MESSAGE);
                }catch(NumberFormatException e){
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Alert!", JOptionPane.ERROR_MESSAGE);
                }catch(CPSC1181Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Alert!", JOptionPane.ERROR_MESSAGE);
                }catch(DateTimeException e){
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Alert!", JOptionPane.ERROR_MESSAGE);   
                }
                
            }
        }
        JButton button = new JButton(title);
        button.addActionListener(new countListener());
        return button;
    }

}