/**
 * CPSC 1181 Lab Assignment 9
 * @author :Qian Ting Huang
 * student#: 100307328
 * @version :2019-07-16
 */

import javax.swing.JFrame;
 /**
  * A program that gets user input times and display the days in between
  */
public class DataFrameViewer
{
    static final int WIDTH = 680;
    static final int HEIGHT = 80;
    public static void main(String[] args){
        JFrame frame = new JFrame();
        DataCounterPanel dataCounterPanel = new DataCounterPanel();
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(WIDTH, HEIGHT);
        frame.setResizable(false);

        frame.add(dataCounterPanel);

        frame.setVisible(true);
    }
}