/**
 * CPSC 1181 Lab Assignment 9
 * @author :Qian Ting Huang
 * student#: 100307328
 * @version :2019-07-16
 */

import java.lang.NumberFormatException;
import java.time.DateTimeException;
import java.time.LocalDate;
/**
 * class that will verify input data
 */
public class DataVerifier
{
    private CPSC1181Exception exceptions;
    private String[] data;
    private int day, month, year;
    /**
     * constructor
     */
    public DataVerifier()
    {
    }

    /**
     * verifies string input got from text field, transform the input into date format and return
     * it if it is valid.
     * @param input :the string from text field
     * @return :transfer the string input into date variable
     * @throws NumberFormatException
     * @throws CPSC1181Exception
     * @throws DateTimeException
     */
    public LocalDate verify(String input)
        throws NumberFormatException, CPSC1181Exception, DateTimeException
    {
        //splits string and varify the format
        data = input.split("/",-1);
        if (data.length != 3) throw invalidInputException();
        if (data[0].length() > 2 || data[0].length() < 1) throw invalidInputException();
        if (data[1].length() > 2 || data[1].length() < 1) throw invalidInputException();
        if (data[2].length() != 4) throw invalidInputException();
        //transform input string into date variable, will varify validity
        try{
            day = Integer.parseInt(data[0]);
            month = Integer.parseInt(data[1]);
            year = Integer.parseInt(data[2]);
            getDateError(day, month, year);
            return LocalDate.of(year,month,day);
        }catch(NumberFormatException exception){
            exception = new NumberFormatException("Invalid Date Format!\nPlease follow the format DD/MM/YYYY");
            throw exception;
        }catch(DateTimeException exception){
            throw exception;
        }
    }

    /**
     * varify if the date is a valid exsisting day in the calendar
     * will throw exception if invalid date
     * will do nothing if input is valid
     * @param day :day
     * @param month :month as integer
     * @param year :year
     */
    private void getDateError(int day, int month, int year)
    {
        String dateError = "";
        if (day < 1 || month < 1 || year < 1) dateError+=", date can not be negative or zero!";
        else if (year > 3000) dateError+=", year can not exceed 3000!";
        else if (year < 1000) dateError+=", year can not be less than 1000!";
        else if (month > 12) dateError+=", month can not be more than 12!";
        else if (day > 31) dateError+=", no more than 31 days in a month!";
        else switch (month){
            case 4: case 6: case 9: case 11:
            if (day > 30) dateError+=", no more than 30 days in month "+month+"!";
            break;
            //checking leap year
            case 2:
            if ((year%4==0 && year%100==0) || year%400==0){
                if (day > 29) dateError+=", no more than 29 days in Febuary, "+year+"!";
            }else if (day > 28) dateError+=", no more than 28 days in Febuary, "+year+"!";
            break;
        }

        if (dateError.length() == 0) return;
        else throw new DateTimeException("Invalid Date"+dateError);
    }

    /**
     * private method to create a pre-defined exception
     * @return :a invalid input exception
     */
    private CPSC1181Exception invalidInputException()
    {
        exceptions = new CPSC1181Exception("Input format is invalid!");
        return exceptions;
    }
}