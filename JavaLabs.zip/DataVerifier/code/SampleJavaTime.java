import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.DateTimeException;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class SampleJavaTime{
	public static void main(String[] args){
		String day = ""+LocalDateTime.now().getDayOfMonth();
		String month = ""+LocalDateTime.now().getMonthValue();
		String year = ""+LocalDateTime.now().getYear();
		System.out.printf("\nTodya: %s/%s/%s\n",year,month,day);

		LocalDate start = LocalDate.of(2018, 2, 21);
		LocalDate end = LocalDate.of(2019, 5, 29);
		Period duration = Period.between(start, end);
		// use Period getDays(), getMonths(), and getYears() method for the duration. Check Java API for more info.

		long numberOfDays = ChronoUnit.DAYS.between(start, end);
		// returns number of days between two dates. Check Java API for mor info.
		System.out.println(numberOfDays);


		



	}
}