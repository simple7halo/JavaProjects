/*
CPSC 1181 Lab Assignment 1
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: Address.java
Description: A class address
Properties:
   Unit number
   Street name
   City name
   Province name
   Postal code
*@author Qian Ting Huang
*@version 2019-05-16
*/

public class Address
{
	/**
		Properties
	*/
	private String unitNumber; //address' unit number
	private String street; //address' street name
	private String city; //city name
	private String province; //province name
	private String postalCode; //postal code
	
	/**
		default constructor
	*/
	public Address(){
		//Defaul value set to unknown
		unitNumber = "####";
		street = "UnknownStreet";
		city = "UnknownCity";
		province = "UnknownProvince";
		postalCode = "######";
	}
	
	/**
		Creates an address
		and setup it's properties
	*/
	public Address(String unitNumber, String street, String city, String province, String postalCode){
		this.unitNumber = unitNumber;
		this.street = street;
		this.city = city;
		this.province = province;
		this.postalCode = postalCode;
	}
	
	/**
		return address as string
		@return the address information in a sentence format
	*/
	public String getAdd(){
		String add = "";
		add += unitNumber;
		add += " ";
		add += street;
		add += ", ";
		add += city;
		add += ", ";
		add += province;
		add += " ";
		add += postalCode;
		return add;
	}
}