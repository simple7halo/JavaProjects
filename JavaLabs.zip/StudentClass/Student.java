/*
CPSC 1181 Lab Assignment 1
Student: Qian Ting Huang
Student #: 100307328
*/
/**
File: Student.java
Description: A class Student
Properties:
   Name and Surname
   Student Number
   Address
   Quiz point average
   Login id that is assigned "by the system" when the student is constructed
*@author Qian Ting Huang
*@version 2019-05-16
*/

public class Student
{
	/**
		Properties
	*/
	private String firstName, surName; //student's name and surname
	private long studentNumber; //student's student number
	private Address stuAdd; //student's address
	private double quizTotal, quizAverage; //student's quiz total mark and average mark
	private int quizNumber; //number of quiz taken by student
	private String studentId; //student login id
	   
	/**
		Creates a student
		A student have first name and surname, and studentId
	*/
	public Student(String firstName, String surName, long studentId){
		this.firstName = firstName;
		this.surName = surName;
		studentNumber = studentId;
		generateId(); //generate student Id
		stuAdd = new Address();
		//initialize student as he/she took 0 quiz before
		quizTotal = 0; 
		quizNumber = 0; 
		quizAverage = 0;
	}
	
	/**
		generate student's login Id
	*/
	public void generateId(){
		studentId = "";
		//take first letter of first name and switch to lower case if needed
		if ((firstName.charAt(0) >= 'A') && (firstName.charAt(0) <= 'Z'))
			studentId += (char)(firstName.charAt(0) - 'A' + 'a');
		else
			studentId += firstName.charAt(0);
		
		if (surName.length() <= 4) studentId += surName;
		else studentId += surName.substring(0, 4);
		//get the last two digit of student number
		String num = "" + studentNumber;
		num = num.substring(num.length()-2);
		studentId += num;
	}
	
	/**
		set student's name and surname. Changing student's name does not affect the
		students's loginId
		@param firstName: first name of student
		@param surName: last name of student
		@param studentNumber: the student's student number
	*/
	public void setName(String firstName, String surName, long studentNumber){
		this.firstName = firstName;
		this.surName = surName;
		this.studentNumber = studentNumber;
	}
	
	/**
		returns name and surname separated by comma
		@return the name of the student
	*/
	public String getName(){
		String name = "";
		name += firstName;
		name += ", ";
		name += surName;
		return name;
	}
	
	/**
		returns student number
		@return the student's student number
	*/
	public long getStudentNumber(){
		return studentNumber;
	}
	
	/**
		returns the students login Id
		return: the login Id of the student
	*/
	public String getLoginId(){
		return studentId;
	}
	
	/**
		returns student's info with following format
		name, surname (student number, Student login in) <<< this is the format in test case
		@return general information about the student in a certain format
	*/
	public String getInfo(){
		String info = "";
		info += getName();
		info += "(";
		info += getStudentNumber();
		info += ", ";
		info += getLoginId();
		info += ")";
		return info;
	}
	
	/**
		sets address of the student
		@param number: the unit number of student's address
		@param street: the street of student's address
		@param city: the city of student's address
		@param province: the province of student's address
		@param postalCode: the postal code of student's address
	*/
	public void setAddress(String number, String street, String city, String province, String postalCode){
		stuAdd = new Address(number, street, city, province, postalCode);
	}
	
	/**
		returns student's address
		@return the student's address
	*/
	public String getAddress(){
		String add = "";
		add += stuAdd.getAdd();
		return add;
	}
	
	/**
		add a quiz score to the student
		@param quiz: the quiz score that will be added into student's quiz's record
	*/
	public void addQuiz(double quiz){
		quizTotal += quiz;
		quizNumber ++;
		quizAverage = quizTotal / quizNumber;
	}
	
	/**
		returns the average of the quiz of a student
		@return the student's average point of quizs
	*/
	public double getQuizAverage(){
		return quizAverage;
	}
	
	@Override
	public String toString(){
		String output = "[";
		output += getName();
		output += getStudentNumber();
		output += ", ";
		output += getLoginId();
		output += "]";
		// complete information for toString method
		output += "\n[Address: ";
		output += getAddress();
		output += "]\n[Quiz Average: ";
		output += getQuizAverage();
		output += "]";
		
		return output;
		
	}
	
}