/**
	StudentTester tests class Student and class Address 

*/
class StudentTester{
	public static void main(String[] args){
		// test Student constructor
		Student student = new Student("Marry","jones",10000001);
		System.out.println("Test student constructor:");
		System.out.println(student); 
		System.out.println("");

		// test Student getName, geyStudentNumber(), getLoginId()
		System.out.println("Test getName:");
		System.out.println(student.getName());
		System.out.println("\nTest getStudentNumber:");
		System.out.println(student.getStudentNumber());
		System.out.println("\nTest getLoginId:");
		System.out.println(student.getLoginId());
		System.out.println("");


		// test Student getInfo()
		System.out.println("Test getInfo:");
		System.out.println(student.getInfo());
		System.out.println("");

		// test Student addQuiz and getAverage
		System.out.println("Test addQuiz and getAverage:");
		student.addQuiz(6.0);
		student.addQuiz(8.5);
		student.addQuiz(9.8);
		System.out.println(student.getQuizAverage());
		System.out.println("");
		
		// add your test cases:
		
		//test student setName
		System.out.println("Test setName:");
		student.setName("Not", "Marry", 10000002);
		System.out.println(student.getInfo());
		System.out.println("");

		//Test setAddress() and getAddress()
		System.out.println("Test setAddress() and getAddress():");
		student.setAddress("0101", "SomeSt", "ACity", "B.C.", "V22ABC");
		System.out.println(student.getAddress());





	}
}