/**
	A Circle is specified by its center (x,y) and radius
*/
public class Circle{
	private double radius;
	private Point center;
	
	/**
	Construct a unit circle at origin(0,0) 
	*/
	public Circle(){
		center = new Point();
		radius=1;
	}
	/**
	Construct a circle with center at (x,y) with r=radius
	*/
	public Circle(double x, double y, double radius){
		center = new Point(x,y);
		this.radius = radius;
	}

	/**
	move the circle by moving its center to a new coordinate
	@param x : x-coordinate of the center
	@param y : y-coordinate of the center
	*/
	public void move(double x, double y){
		center.move(x,y);

	}

	/**
	sets the radius of the circle
	@param radius: radius of the circle
	*/
	public void setRadius(double radius){
		this.radius = radius;

	}
	/**
	returns the radius of the circle
	@return radius of the circle
	*/
	public double getRadius(){
		return radius;
	}


	/**
		Calculates and returns the area of the circle
		@return area of the circle
	*/
	public double getArea(){

		return Math.pow(radius,2)*Math.PI;

	}

	/**
	Calculates and returns the Circumference of the circle
	@return circumference of the circle
	*/
	public double getCircumference(){

		return 2*radius*Math.PI;

	}

	@Override
	public String toString(){
		return "[x:"+center.toString()+", radius:"+radius+"]";
	}
	
}

