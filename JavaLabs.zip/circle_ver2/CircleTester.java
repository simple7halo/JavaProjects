/**
	Test Harness to test class Circle
*/
public class CircleTester{
	public static void main(String[] args){
		Circle c1 = new Circle();
		System.out.println(c1);
		Circle c2 = new Circle(25,26.8, 25.47);
		System.out.println(c2);

		c2.setRadius(456);
		System.out.println(c2);

		System.out.println(c2.getRadius());
		// rest of the test cases
	}
}