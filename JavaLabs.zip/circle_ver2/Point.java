/**
	A Point is specified by its coordinates x and y
*/
public class Point{
	private double x;
	private double y;
	/**
	Default Constructor
	*/
	public Point(){
		x=y=0;
	}
	/**
	Construc a Point object at coordiantes x and y
	@param x: x-coordinates of the point
	@param y: y-coordinates of the point
	*/
	public Point(double x, double y){
		this.x = x;
		this.y = y;
		
	}
	/**
	Move point to x and y coordinate
	@param x: x-coordinates of new location
	@param y: y-coordinates of the new location
	*/
	public void move(double x, double y){
		this.x = x;
		this.y = y;
	}
	/** 
	returns x-coordinate of the point
	*/
	public double getX(){
		return x;
	}
	/** 
	returns y-coordinate of the point
	*/
	public double getY(){
		return y;
	}

	@Override
	public String toString(){
		return "[x:"+x+", y:"+y+"]";
	}
}